# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score, KFold, GridSearchCV
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import joblib
import warnings

plt.rcParams['font.sans-serif'] = ['SimSun', 'SimHei', 'Microsoft YaHei']
plt.rcParams['font.family'] = ['Times New Roman', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 16

df = pd.read_excel('data.xlsx')
print(df.head())

X = df.iloc[:, :-1].values
y = df.iloc[:, -1].values

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
print("train:", X_train.shape, "test:", X_test.shape)

scaler_X = StandardScaler()
scaler_y = StandardScaler()

X_train_scaled = scaler_X.fit_transform(X_train)
X_test_scaled = scaler_X.transform(X_test)

y_train_scaled = scaler_y.fit_transform(y_train.reshape(-1,1)).ravel()
y_test_scaled = scaler_y.transform(y_test.reshape(-1,1)).ravel()

param_grid = {
    'C': [1000, 1500],
    'epsilon': [0.001, 0.01, 0.05],
    'gamma': ['scale', 0.001, 0.01, 0.1]
}   # 'C': [1, 10, 50, 100, 200, 500, 1000, 1500]


with warnings.catch_warnings():
    warnings.filterwarnings("ignore")
    grid_search = GridSearchCV(
        SVR(kernel='rbf'),
        param_grid,
        cv=5,
        scoring='neg_mean_squared_error',
        n_jobs=-1,
        verbose=1
    )
    grid_search.fit(X_train_scaled, y_train_scaled)



best_svr = grid_search.best_estimator_

cv = KFold(n_splits=10, shuffle=True, random_state=42)
with warnings.catch_warnings():
    warnings.filterwarnings("ignore")
    cv_scores = cross_val_score(best_svr, X_train_scaled, y_train_scaled, cv=cv, scoring='neg_mean_squared_error')
cv_rmse = np.sqrt(-cv_scores)
print(f"十折 CV RMSE: mean={cv_rmse.mean():.4f}, std={cv_rmse.std():.4f}")


y_test_pred_scaled = best_svr.predict(X_test_scaled)
y_test_pred = scaler_y.inverse_transform(y_test_pred_scaled.reshape(-1,1)).ravel()

test_r2 = r2_score(y_test, y_test_pred)
test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
test_mae = mean_absolute_error(y_test, y_test_pred)


print("R²:", test_r2)
print("RMSE:", test_rmse)
print("MAE:", test_mae)


plt.figure(figsize=(7,5))
plt.scatter(y_test, y_test_pred, s=15)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], '--', color='red', linewidth=2)
plt.text(0.05, 0.90, f'R² = {test_r2:.4f}', transform=plt.gca().transAxes)
plt.text(0.05, 0.85, f'RMSE = {test_rmse:.4f}', transform=plt.gca().transAxes)
plt.text(0.05, 0.80, f'MAE = {test_mae:.4f}', transform=plt.gca().transAxes)
plt.xlabel("True FOS")
plt.ylabel("Predicted FOS")
plt.grid(True)
plt.tight_layout()
plt.show()


joblib.dump({
    'model': best_svr,
    'scaler_X': scaler_X,
    'scaler_y': scaler_y,
    'best_params': grid_search.best_params_
}, 'svr_regressor_best.pkl')





