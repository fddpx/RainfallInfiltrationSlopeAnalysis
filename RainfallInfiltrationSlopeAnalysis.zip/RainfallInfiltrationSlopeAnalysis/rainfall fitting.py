# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from scipy import stats
from scipy.stats import genpareto, lognorm, norm, expon, genextreme, kendalltau
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from copulae import FrankCopula
import warnings
import json
from scipy import integrate

warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False


marginal_distributions = {
    'GPD': genpareto,            
    'Lognormal': lognorm,
    'Normal': norm,
    'Exp': expon,
    'GEV': genextreme                 
}


def fit_and_evaluate_distribution(data):
    results = []

    for name, dist in marginal_distributions.items():
        try:
            params = dist.fit(data)
            loglik = np.sum(dist.logpdf(data, *params))
            k = len(params)
            aic = 2*k - 2*loglik

            if name in ['GPD', 'GEV',"Exponential","Lognormal","Normal"]:
                cdf_vals = dist.cdf(data, *params)
                ks_stat, ks_pvalue = stats.kstest(cdf_vals, 'uniform')
            else:
                ks_stat, ks_pvalue = stats.kstest(data, dist.name.lower(), args=params)

            results.append({
                'name': name,
                'dist': dist,
                'params': params,
                'loglik': loglik,
                'aic': aic,
                'ks_stat': ks_stat,
                'ks_pvalue': ks_pvalue
            })

            plot_distribution(data, dist, params, name, aic, ks_pvalue)

        except Exception as e:
            print(f" {name} failed: {e}")

    results.sort(key=lambda x: x['aic'])
    return results

def plot_distribution(data, dist, params, dist_name, aic, ks_pvalue):
    plt.rcParams['font.size'] = 16
    plt.rcParams['font.family'] = ['Times New Roman', 'SimSun']
    fig, ax_freq = plt.subplots(figsize=(7,4.5))
    ax_pdf = ax_freq.twinx()

    n, bins, _ = ax_freq.hist(data, bins=30, alpha=0.5, color='lightblue', edgecolor='black', label='Histogram')
    ax_freq.set_ylabel('Frequency', color='blue', fontsize=16)
    ax_freq.tick_params(axis='y', labelcolor='blue')

    x = np.linspace(min(data), max(data), 500)
    pdf = dist.pdf(x, *params)
    ax_pdf.plot(x, pdf, 'r-', lw=2, label=f'{dist_name} distribution ')
    ax_pdf.set_ylabel('Density', color='red', fontsize=16)
    ax_pdf.tick_params(axis='y', labelcolor='red')

    ax_freq.set_ylim(0, max(n)*1.05)
    ax_pdf.set_ylim(0, max(pdf)*1.05)

    ax_freq.set_xlabel('Rainfall intensity (mm/h)', fontsize=16)
    title = f'{dist_name} \nAIC={aic:.1f}, K-S p={ks_pvalue:.3f}'

    lines1, labels1 = ax_freq.get_legend_handles_labels()
    lines2, labels2 = ax_pdf.get_legend_handles_labels()
    ax_freq.legend(lines1 + lines2, labels1 + labels2, loc='best')

    plt.tight_layout()
    plt.show()

def frank_copula_pdf(u, v, theta):
    num = theta * np.exp(-theta*(u+v)) * (1 - np.exp(-theta))
    denom = (1 - np.exp(-theta) - (1 - np.exp(-theta*u))*(1 - np.exp(-theta*v)))**2
    return num / denom


duration = pd.read_csv('rain_duration_table.csv')['duration_hours'].values
intensity = pd.read_csv('rain_intensity_table.csv')['rain_intensity'].values


duration_results = fit_and_evaluate_distribution(duration)

intensity_results = fit_and_evaluate_distribution(intensity)

best_duration = duration_results[0]
best_intensity = intensity_results[0]


ks_test_count = 0
def ks_test_best(data, best_result, alpha=0.05):
    global ks_test_count
    ks_test_count += 1

    dist_name = best_result['name']
    dist = best_result['dist']
    params = best_result['params']
    n = len(data)

    if dist_name in ['GPD', 'GEV', "Exponential", "Lognormal", "Normal"]:
        cdf_vals = dist.cdf(data, *params)
        ks_stat, p_value = stats.kstest(cdf_vals, 'uniform')
    else:
        ks_stat, p_value = stats.kstest(data, dist.name.lower(), args=params)

    significance = "pass" if p_value > alpha else

    D_crit = 1.36 / np.sqrt(n)
    crit_sign = "pass" if ks_stat < D_crit else


    x = np.sort(data)
    y_empirical = np.arange(1, len(x) + 1) / len(x)
    y_theoretical = dist.cdf(x, *params)
    plt.figure(figsize=(7, 4.5))
    plt.rcParams['font.size'] = 16
    plt.rcParams['font.family'] = ['Times New Roman', 'SimSun']
    plt.step(x, y_empirical, where='post', label='empirical CDF', color='blue', linewidth=2)
    plt.plot(x, y_theoretical, 'r--', label='theoretical CDF', linewidth=2)
    plt.axhline(y=ks_stat, color='green', linestyle='--', linewidth=2, label=f'd-statistic: {ks_stat:.4f}')
    plt.axhline(y=D_crit, color='orange', linestyle='--', linewidth=2, label=f'critical d-value: {D_crit:.4f}')

    plt.plot([], [], ' ', label=f'significance level: {alpha}')
    plt.plot([], [], ' ', label=f'p-value: {p_value:.4f}')
    plt.plot([], [], ' ', label=f'test result : {significance}')

    if ks_test_count == 1:
        plt.xlabel('Rainfall duration (h)', fontproperties='Times New Roman', fontsize=16)
    elif ks_test_count == 2:
        plt.xlabel('Rainfall intensity (mm/h)', fontproperties='Times New Roman', fontsize=16)
    else:
        plt.xlabel('V', fontproperties='SimSun', fontsize=16)

    plt.ylabel('CDF', fontproperties='Times New Roman')
    plt.legend(prop={'family': ['Times New Roman', 'SimSun']}, fontsize=16)
    plt.grid(False)
    plt.tight_layout()
    plt.show()

    return ks_stat, p_value, D_crit

ks_test_count = 0
ks_test_best(duration, best_duration)
ks_test_best(intensity, best_intensity)


print(f"\n durantion: {best_duration['name']}, paras={best_duration['params']}")
print(f"intensity: {best_intensity['name']}, paras={best_intensity['params']}")

eps = 1e-6
u = best_duration['dist'].cdf(duration, *best_duration['params'])
v = best_intensity['dist'].cdf(intensity, *best_intensity['params'])
u = np.clip(u, eps, 1-eps)
v = np.clip(v, eps, 1-eps)

def neg_log_likelihood(theta):
    pdf_vals = frank_copula_pdf(u, v, theta)
    pdf_vals = np.clip(pdf_vals, 1e-12, None)
    return -np.sum(np.log(pdf_vals))

res = minimize(neg_log_likelihood, x0=[1.0], bounds=[(0.0001, 20)])
theta_hat = res.x[0]
print(f"\n Frank Copula  θ = {theta_hat:.4f}")

tau, _ = kendalltau(duration, intensity)
print(f"样本Kendall τ = {tau:.3f}")

def integrand(t):
    return t / (np.exp(t) - 1)
result, error = integrate.quad(integrand, 0, theta_hat)
D1 = result / theta_hat
tau_theory = 1 - (4/theta_hat) * (1 - D1)
print(f"τ = {tau_theory:.6f}")


save_dict = {
    'duration': {'dist': best_duration['dist'].name, 'params': best_duration['params']},
    'intensity': {'dist': best_intensity['dist'].name, 'params': best_intensity['params']},
    'theta': theta_hat
}

with open('copula_params.json', 'w') as f:
    json.dump(save_dict, f, indent=4)

np.random.seed(15)
n_samples = 1000
copula = FrankCopula(dim=2, theta=theta_hat)
uniform_samples = copula.random(n_samples)

duration_samples = best_duration['dist'].ppf(uniform_samples[:, 0], *best_duration['params'])
intensity_samples = best_intensity['dist'].ppf(uniform_samples[:, 1], *best_intensity['params'])

df = pd.DataFrame({
    'Duration (h)': duration_samples,
    'Rainfall Intensity (mm/h)': intensity_samples
}).round(2)
with open('Duration.txt', 'w') as f:
    f.write("Duration Data\n")
    f.write(f"{n_samples} 0.0\n")
    for i, val in enumerate(df['Duration (h)'], 1):
        f.write(f"{i} {val:.2f}\n")
with open('Rainfall_Intensity.txt', 'w') as f:
    f.write("Rainfall Intensity Data\n")
    f.write(f"{n_samples} 0.0\n")
    for i, val in enumerate(df['Rainfall Intensity (mm/h)'], 1):
        f.write(f"{i} {val:.2f}\n")
fig, axes = plt.subplots(1, 2, figsize=(12,5))

def plot_dual_axis_hist_pdf_ax(ax_freq, data, pdf_vals, x_vals, title, xlabel, hist_color='lightblue', pdf_color='red'):
    ax_pdf = ax_freq.twinx()

    n, bins, _ = ax_freq.hist(data, bins=50, alpha=0.5, color=hist_color, edgecolor='black', label='fra率', density=False)
    ax_freq.set_ylabel('fra', color='blue')
    ax_freq.tick_params(axis='y', labelcolor='blue')

    ax_pdf.plot(x_vals, pdf_vals, color=pdf_color, lw=2, label='th_den')
    ax_pdf.set_ylabel('den', color='red')
    ax_pdf.tick_params(axis='y', labelcolor='red')

    ax_freq.set_ylim(0, max(n)*1.05)
    ax_pdf.set_ylim(0, max(pdf_vals)*1.05)

    ax_freq.set_xlabel(xlabel)
    ax_freq.set_title(title)

    lines1, labels1 = ax_freq.get_legend_handles_labels()
    lines2, labels2 = ax_pdf.get_legend_handles_labels()
    ax_freq.legend(lines1 + lines2, labels1 + labels2, loc='best')

D_vals = np.linspace(min(duration_samples), max(duration_samples)*1.2, 500)
pdf_D = best_duration['dist'].pdf(D_vals, *best_duration['params'])
plot_dual_axis_hist_pdf_ax(axes[0], duration_samples, pdf_D, D_vals,
                           xlabel='D (h)', hist_color='lightgreen', pdf_color='green')

I_vals = np.linspace(min(intensity_samples), max(intensity_samples)*1.2, 500)
pdf_I = best_intensity['dist'].pdf(I_vals, *best_intensity['params'])
plot_dual_axis_hist_pdf_ax(axes[1], intensity_samples, pdf_I, I_vals,
                           xlabel='I (mm/h)', hist_color='skyblue', pdf_color='blue')

plt.tight_layout()
plt.show()


