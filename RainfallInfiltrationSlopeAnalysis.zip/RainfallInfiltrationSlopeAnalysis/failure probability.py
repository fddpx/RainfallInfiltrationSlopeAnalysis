# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
from copulae import FrankCopula
from scipy.stats import genpareto, lognorm, norm, expon, genextreme
import json
import joblib
import os
import matplotlib.pyplot as plt
import seaborn as sns
import time


plt.rcParams['font.sans-serif'] = ['SimSun', 'SimHei', 'Microsoft YaHei']
plt.rcParams['font.family'] = ['Times New Roman', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 13



TARGET_CV = 0.1
MAX_ITER = 1000
MIN_ITER = 1000
RAIN_SAMPLES = 34
SOIL_SAMPLES = 10000
OUTPUT_DIR = 'predictions_mc_max'
os.makedirs(OUTPUT_DIR, exist_ok=True)


with open('copula_params.json', 'r') as f:
    params = json.load(f)


def get_dist(dist_name):
    mapping = {
        'genpareto': genpareto,
        'lognorm': lognorm,
        'norm': norm,
        'expon': expon,
        'genextreme': genextreme
    }
    return mapping[dist_name]

duration_dist = get_dist(params['duration']['dist'])
duration_params = tuple(params['duration']['params'])
intensity_dist = get_dist(params['intensity']['dist'])
intensity_params = tuple(params['intensity']['params'])
theta_hat = params['theta']


variables = [
    (8e3, 0.15),
    (24, 0.10),
]
variable_names = ['nianjuli', 'mocajiao']

np.random.seed(1)
all_samples = {}
for i, (mu_X, CV) in enumerate(variables):
    sigma_ln = np.sqrt(np.log(1 + CV ** 2))
    mu_ln = np.log(mu_X) - 0.5 * sigma_ln ** 2
    ln_lower = mu_ln - 3 * sigma_ln
    ln_upper = mu_ln + 3 * sigma_ln
    samples = []
    while len(samples) < SOIL_SAMPLES:
        ln_s = np.random.normal(loc=mu_ln, scale=sigma_ln, size=2*SOIL_SAMPLES)
        ln_s = ln_s[(ln_s >= ln_lower) & (ln_s <= ln_upper)]
        samples.extend(ln_s.tolist())
    all_samples[variable_names[i]] = np.exp(np.array(samples[:SOIL_SAMPLES]))
soil_df = pd.DataFrame(all_samples)


svr_dict = joblib.load('svr_regressor_best.pkl')
svr_model = svr_dict['model']
scaler_X = svr_dict['scaler_X']
scaler_y = svr_dict['scaler_y']



np.random.seed(1)
max_fail_probs_year = []
iteration = 0
iteration_log_path = os.path.join(OUTPUT_DIR, 'iteration_log.csv')
iteration_log = []


while True:
    iteration += 1
    print(f"\n🔹 Iteration {iteration}")

    copula = FrankCopula(dim=2, theta=theta_hat)
    duration_samples = []
    intensity_samples = []
    while len(duration_samples) < RAIN_SAMPLES:
        batch_size = RAIN_SAMPLES - len(duration_samples)
        uniform_samples = copula.random(batch_size * 2)
        D_batch = duration_dist.ppf(uniform_samples[:, 0], *duration_params)
        I_batch = intensity_dist.ppf(uniform_samples[:, 1], *intensity_params)
        mask = (D_batch >= 0.5) & (D_batch <= 28) & (I_batch >= 0.38) & (I_batch <= 5)
        duration_samples.extend(D_batch[mask])
        intensity_samples.extend(I_batch[mask])
    duration_samples = np.array(duration_samples[:RAIN_SAMPLES])
    intensity_samples = np.array(intensity_samples[:RAIN_SAMPLES])


    fail_probs = []
    for i in range(RAIN_SAMPLES):
        rain_features = np.array([duration_samples[i], intensity_samples[i]])
        rain_matrix = np.tile(rain_features, (SOIL_SAMPLES, 1))
        X_combined = np.hstack([rain_matrix, soil_df.values])

        #  SVR 
        X_scaled = scaler_X.transform(X_combined)
        y_pred_scaled = svr_model.predict(X_scaled)
        y_pred = scaler_y.inverse_transform(y_pred_scaled.reshape(-1,1)).ravel()
        fail_prob = np.mean(y_pred < 1)
        fail_probs.append(fail_prob)


    year_max_fail_prob = max(fail_probs)
    max_fail_probs_year.append(year_max_fail_prob)


    iteration_info = {
        'iteration': iteration,
        'year_max_fail_prob': year_max_fail_prob,
        'duration_samples_mean': np.mean(duration_samples),
        'intensity_samples_mean': np.mean(intensity_samples),
        'all_fail_probs_mean': np.mean(fail_probs),
        'all_fail_probs_std': np.std(fail_probs)
    }
    iteration_log.append(iteration_info)

    print(f"Iteration {iteration}: year_max_fail_prob = {year_max_fail_prob:.4f}")



    if iteration >= MAX_ITER:
        break


mc_df = pd.DataFrame({
    'iteration': np.arange(1, len(max_fail_probs_year)+1),
    'year_max_fail_prob': max_fail_probs_year
})
mc_df.to_csv(os.path.join(OUTPUT_DIR, 'year_max_fail_probs_mc.csv'), index=False)
iteration_df = pd.DataFrame(iteration_log)
iteration_df.to_csv(iteration_log_path, index=False)
print(f"\n Monte Carlo output {OUTPUT_DIR}")


mean_prob = np.mean(max_fail_probs_year)
std_prob = np.std(max_fail_probs_year)
cv_final = std_prob / mean_prob
min_prob = np.min(max_fail_probs_year)
max_prob = np.max(max_fail_probs_year)

print(f"\n🎯 Final results:")
print(f"   Mean year max failure probability: {mean_prob:.6f}")
print(f"   Standard deviation: {std_prob:.6f}")
print(f"   Coefficient of variation: {cv_final:.6f}")
print(f"   Minimum year max failure probability: {min_prob:.6f}")
print(f"   Maximum year max failure probability: {max_prob:.6f}")
print(f"   Number of iterations: {len(max_fail_probs_year)}")



fig, ax1 = plt.subplots(figsize=(8,5))
n, bins, patches = ax1.hist(max_fail_probs_year, bins=30, alpha=0.7, color='skyblue',
                           edgecolor='black', linewidth=0.5)
ax1.set_xlabel('Maximum failure probability')
ax1.set_ylabel('Frequency')

ax1.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, 'year_max_fail_prob_histogram.png'), dpi=300, bbox_inches='tight')
plt.show()
