import xarray as xr
import matplotlib.pyplot as plt
import os
import glob
import pandas as pd
import numpy as np

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimSun', 'SimHei', 'Microsoft YaHei']
plt.rcParams['font.family'] = ['Times New Roman', 'SimSun']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 13

data_dir = "data"

nc_files = sorted(glob.glob(os.path.join(data_dir, "ERA5Land_precip_*", "data_0.nc")))

print(f"fine {len(nc_files)}  NetCDF file")

datasets = []
for f in nc_files:
    ds = xr.open_dataset(f)
    tp_point = ds['tp'].sel(latitude=41, longitude=110, method="nearest")
    tp_point_mm = tp_point * 1000
    datasets.append(tp_point_mm)

tp_all = xr.concat(datasets, dim='valid_time')

time_values = tp_all['valid_time'].values
time_datetime = pd.to_datetime(time_values)
tp_values = tp_all.values

hourly_precip = np.zeros(len(tp_values))
for i in range(len(tp_values)):
    current_time = time_datetime[i]
    if current_time.hour == 1 and current_time.minute == 0:
        hourly_precip[i] = tp_values[i]
    elif i > 0:
        hourly_precip[i] = tp_values[i] - tp_values[i - 1]
    else:
        hourly_precip[i] = tp_values[i]


fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 9))
ax1.plot(time_values, tp_values, color='b', linewidth=1, marker='o', markersize=2, linestyle='-')
ax1.set_ylabel("24-hour cumulative rainfall (mm)")
ax1.grid(True, alpha=0.3)
ax1.tick_params(axis='x', rotation=45)
ax2.plot(time_values, hourly_precip, color='r', linewidth=1, marker='s', markersize=2, linestyle='-')
ax2.set_ylabel("Hourly rainfall intensity  (mm/h)")
ax2.grid(True, alpha=0.3)
ax2.tick_params(axis='x', rotation=45)
plt.tight_layout()
plt.show()


tp_series = pd.Series(hourly_precip, index=pd.to_datetime(time_values))

rain_thresh = 0.5   
ietd_hours = 9
min_segment_duration = 0.5

def interpolate_start_time(time_before, time_after, rain_before, rain_after, threshold):
    if rain_before >= threshold or rain_after < threshold:
        return time_after
    time_diff = (time_after - time_before).total_seconds()
    rain_diff = rain_after - rain_before
    fraction = (threshold - rain_before) / rain_diff if rain_diff != 0 else 0
    return time_before + pd.Timedelta(seconds=time_diff * fraction)

def interpolate_end_time(time_before, time_after, rain_before, rain_after, threshold):
    if rain_before < threshold or rain_after >= threshold:
        return time_before
    time_diff = (time_after - time_before).total_seconds()
    rain_diff = rain_after - rain_before
    fraction = (threshold - rain_before) / rain_diff
    return time_before + pd.Timedelta(seconds=time_diff * fraction)

df = pd.DataFrame({'precipitation': tp_series.values}, index=tp_series.index)

rain_segments = []
in_segment = False
seg_start = None
seg_rain = 0.0

for i in range(len(df)):
    t = df.index[i]
    r = df['precipitation'].iloc[i]

    if r >= rain_thresh:
        if not in_segment:
            seg_start = t
            if i > 0:
                prev_t = df.index[i - 1]
                prev_r = df['precipitation'].iloc[i - 1]
                if prev_r < rain_thresh:
                    seg_start = interpolate_start_time(prev_t, t, prev_r, r, rain_thresh)
            in_segment = True
            seg_rain = r
            seg_end = t
        else:
            seg_end = t
            seg_rain += r
    else:
        if in_segment:
            end_time = seg_end
            if i > 0:
                left_t = df.index[i - 1]
                left_r = df['precipitation'].iloc[i - 1]
                if left_r >= rain_thresh and r < rain_thresh:
                    end_time = interpolate_end_time(left_t, t, left_r, r, rain_thresh)
            rain_segments.append({
                'start': seg_start,
                'end': end_time,
                'total_rain': seg_rain
            })
            in_segment = False

if in_segment:
    rain_segments.append({
        'start': seg_start,
        'end': seg_end,
        'total_rain': seg_rain
    })


filtered_segments = []
for seg in rain_segments:
    duration_hours = (seg['end'] - seg['start']).total_seconds() / 3600
    if duration_hours >= min_segment_duration:
        filtered_segments.append(seg)

rain_segments = filtered_segments

rain_segments = sorted(rain_segments, key=lambda x: x['start'])

events = []
current_event = None

for seg in rain_segments:
    if current_event is None:
        current_event = {
            'start': seg['start'],
            'end': seg['end'],
            'segments': [seg],
            'total_rain': seg['total_rain']
        }
    else:
        gap_hours = (seg['start'] - current_event['end']).total_seconds() / 3600
        if gap_hours <= ietd_hours:
            current_event['segments'].append(seg)
            current_event['end'] = seg['end']
            current_event['total_rain'] += seg['total_rain']
        else:
            events.append(current_event)
            current_event = {
                'start': seg['start'],
                'end': seg['end'],
                'segments': [seg],
                'total_rain': seg['total_rain']
            }

if current_event is not None:
    events.append(current_event)

print(f"total {len(events)} rainfall events")

for idx, event in enumerate(events, 1):
    total_duration = 0
    for seg in event['segments']:
        total_duration += (seg['end'] - seg['start']).total_seconds() / 3600

    start_str = event['start'].strftime('%Y-%m-%d %H:%M:%S')
    end_str = event['end'].strftime('%Y-%m-%d %H:%M:%S')

    print(f"\nevent {idx}:")
    print(f"  start: {start_str}")
    print(f"  end: {end_str}")
    print(f"  duration: {total_duration:.2f} hour")
    print(f"  all: {event['total_rain']:.2f} mm")
    print(f"  num: {len(event['segments'])}")




event_data = []
for idx, event in enumerate(events, 1):
    total_duration = sum(
        (seg['end'] - seg['start']).total_seconds() / 3600 for seg in event['segments']
    )
    rain_intensity = event['total_rain'] / total_duration if total_duration > 0 else 0

    event_data.append({
        'event_id': idx,
        'start_time': event['start'],
        'end_time': event['end'],
        'duration_hours': total_duration,
        'total_rain_mm': event['total_rain'],
        'rain_intensity': rain_intensity,
        'segment_count': len(event['segments'])
    })

df_events = pd.DataFrame(event_data)
df_duration = df_events[['event_id', 'duration_hours']]
df_intensity = df_events[['event_id', 'rain_intensity']]

df_duration.to_csv('rain_duration_table.csv', index=False)
df_intensity.to_csv('rain_intensity_table.csv', index=False)