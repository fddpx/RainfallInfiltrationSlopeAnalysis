import cdsapi
import calendar

# create CDS API
client = cdsapi.Client()

dataset = "reanalysis-era5-land"


area = [41.88, 109.78, 41.65, 110.07]


for year in range(2000, 2025):       # 2000~2025
    for month in range(1, 13):       # 1~12 

        num_days = calendar.monthrange(year, month)[1]
        days = [f"{day:02d}" for day in range(1, num_days+1)]


        times = [f"{hour:02d}:00" for hour in range(24)]


        request = {
            "variable": ["total_precipitation"],
            "year": str(year),
            "month": f"{month:02d}",
            "day": days,
            "time": times,
            "data_format": "netcdf",
            "area": area
        }

        print(f"Downloading {year}-{month:02d}...")

        client.retrieve(dataset, request).download(f"ERA5Land_precip_{year}_{month:02d}.nc")
